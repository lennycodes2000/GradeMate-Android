package com.example.bcbt

import android.util.Log
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore

data class College(
    val collegeName: String,
    val telephone:String,
    val email:String,
    val website:String,
    val logoPath:String,
    val poBox:String
)
val collegeList = mutableListOf<College>()
fun loadCollegeInfo(){
    Firebase.firestore.collection("colleges")
        .document(Constants.collegeId.value)
        .get()
        .addOnSuccessListener { document->
            if(document.exists()){
                val data = document.data
                if(data != null){
                    val collegeInfo = College(
                        collegeName = data["collegeName"] as?  String?:"",
                        telephone = data["telephone"] as?  String?:"",
                        email = data["email"] as?  String?:"",
                        website = data["website"] as?  String?:"",
                        logoPath = data["logoPath"] as?  String?:"",
                        poBox = data["poBox"] as?  String?:"",
                    )
                    collegeList.clear()
                    collegeList.add(collegeInfo)
                    Log.d("College",collegeList.toList().toString())
                }
            }
        }
}