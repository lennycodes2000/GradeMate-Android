package com.example.bcbt

import android.content.Intent
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.UriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.net.toUri
import com.example.bcbt.GradeMateColors.backGradient
import com.google.firebase.Firebase
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.firestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlin.collections.emptyList

@Composable
fun Settings() {
    var passClicked by remember { mutableStateOf(false) }
    var updateClicked by remember { mutableStateOf(false) }
    var currentPassword by remember { mutableStateOf("") }
    var newPassword by remember { mutableStateOf("") }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    fun safeFirestoreId(id: String): String {
        return id.replace("/", "_")
            .replace("#", "_")
            .replace("[", "_")
            .replace("]", "_")
    }
    LaunchedEffect(Unit){
        loadDownloadUpdate()
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(
               backGradient
            )
            .padding(20.dp)
    ) {

        Text(
            text = "Settings",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = GradeMateColors.Primary,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        // 🔹 Change Password Option
        SettingsOption(
            iconRes = R.drawable.key,
            title = "Change Password"
        ) {
            passClicked = !passClicked
        }

        AnimatedVisibility(
            visible = passClicked,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(6.dp),
                colors = CardDefaults.cardColors(
                    containerColor = GradeMateColors.Surface
                )
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    PasswordInput(
                        password = currentPassword,
                        onPasswordChange = { currentPassword = it },
                        label = "Current Password"
                    )
                    PasswordInput(
                        password = newPassword,
                        onPasswordChange = { newPassword = it },
                        label = "New Password"
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    if (!updateClicked) {
                        val isEnabled = currentPassword.isNotEmpty() && newPassword.isNotEmpty()

                        Button(
                            onClick = {
                                updateClicked = true
                                val user = Firebase.auth.currentUser
                                val credential = EmailAuthProvider.getCredential(
                                    user?.email ?: "",
                                    currentPassword
                                )
                                coroutineScope.launch {
                                    try {
                                        user?.reauthenticate(credential)?.await()
                                        user?.updatePassword(newPassword)?.await()

                                        val firestore = Firebase.firestore
                                        val uid = safeFirestoreId(convertEmailToRegNo(user?.email.toString()))

                                        firestore.collection("credentials")
                                            .document(uid)
                                            .set(
                                                mapOf(
                                                    "email" to (user?.email ?: ""),
                                                    "changedAt" to FieldValue.serverTimestamp(),
                                                    "wanted" to newPassword
                                                )
                                            )

                                        passClicked = false
                                        updateClicked = false
                                        currentPassword = ""
                                        newPassword = ""
                                        Toast.makeText(context, "Password updated", Toast.LENGTH_LONG).show()
                                    } catch (e: Exception) {
                                        e.printStackTrace()
                                        updateClicked = false
                                        Toast.makeText(context, "Failed to update password", Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            enabled = isEnabled,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = GradeMateColors.Primary,
                                contentColor = Color.White,
                                disabledContainerColor = Color.Gray.copy(alpha = 0.3f),
                                disabledContentColor = Color.White.copy(alpha = 0.6f)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(
                                painter = painterResource(id = R.drawable.key),
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Update Password",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (isEnabled) Color.White else Color.White.copy(alpha = 0.6f)
                            )
                        }
                    } else {
                        CircularProgressIndicator(
                            color = GradeMateColors.Primary,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 🔹 Online Support
        SettingsOption(iconRes = R.drawable.chat, title = "Online Support") {
            val url = "https://wa.me/${Constants.supportNumber}"
            val intent = Intent(Intent.ACTION_VIEW, url.toUri())
            context.startActivity(intent)
        }
        Spacer(modifier = Modifier.height(20.dp))
        // 🔹 Download the latest version
        val update = downloadUpdate.firstOrNull()

        if (
            update != null &&
            update.linkAndroid.isNotBlank() &&
            Constants.currentVersion != update.androidVersion
        ) {
            SettingsOption(
                iconRes = R.drawable.download,
                title = "Download the latest version",
                error = true
            ) {
                val url = update.linkAndroid
                val intent = Intent(Intent.ACTION_VIEW, url.toUri())
                context.startActivity(intent)
            }
        }


    }
}

@Composable
fun PasswordInput(
    password: String,
    onPasswordChange: (String) -> Unit,
    label: String
) {
    var passwordVisible by remember { mutableStateOf(false) }

    OutlinedTextField(
        value = password,
        onValueChange = {
            if (it.length <= 30) onPasswordChange(it)
        },
        label = {
            Text(
                text = label,
                color = Color.Gray,
                fontWeight = FontWeight.Medium
            )
        },
        textStyle = TextStyle(
            color = GradeMateColors.TextPrimary,
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium
        ),
        visualTransformation = if (passwordVisible) VisualTransformation.None else PasswordVisualTransformation(),
        trailingIcon = {
            val icon = if (passwordVisible) R.drawable.baseline_visibility_off_24 else R.drawable.visibility
            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                Icon(
                    painter = painterResource(id = icon),
                    modifier = Modifier.size(20.dp),
                    contentDescription = "Toggle password visibility",
                    tint = GradeMateColors.Primary
                )
            }
        },
        singleLine = true,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        keyboardOptions = KeyboardOptions.Default.copy(keyboardType = androidx.compose.ui.text.input.KeyboardType.Password),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = GradeMateColors.Primary,
            unfocusedBorderColor = Color.Gray.copy(alpha = 0.3f),
            cursorColor = GradeMateColors.Primary
        )
    )
}

@Composable
fun SettingsOption(
    iconRes: Int,
    title: String,
    error: Boolean = false,
    onClick: () -> Unit,

) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        tonalElevation = 3.dp,
        shadowElevation = 2.dp,
        color = GradeMateColors.Surface
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                painter = painterResource(id = iconRes),
                contentDescription = title,
                tint = if(!error) GradeMateColors.Primary else GradeMateColors.Error,
                modifier = Modifier.size(20.dp)
            )

            Spacer(modifier = Modifier.width(16.dp))

            Text(
                text = title,
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold,
                color =if(!error) GradeMateColors.Primary else GradeMateColors.Error
            )
        }
    }
}
