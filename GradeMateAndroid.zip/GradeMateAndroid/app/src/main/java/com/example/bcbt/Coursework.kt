package com.example.bcbt

import GradeCard
import GradeSummary
import android.R.attr.level
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.lifecycle.viewmodel.compose.viewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Coursework(
    modifier: Modifier = Modifier,
    studentList: List<Student>,
    gradeList: List<Grade>,
    isLoading: Boolean,
    loadStudent: suspend () -> Unit,
    loadGrades: suspend (Int, Int) -> Unit,
    viewModel: CourseworkViewModel = viewModel()
) {
    val sorting = listOf(
        "Level 4 Semester 1",
        "Level 4 Semester 2",
        "Level 5 Semester 1",
        "Level 5 Semester 2",
        "Level 6 Semester 1",
        "Level 6 Semester 2"
    )

    LaunchedEffect(studentList) {
        viewModel.loadInitial(
            studentList = studentList,
            gradeList = gradeList,
            loadStudent = loadStudent,
            loadGrades = loadGrades
        )
    }

    Column(modifier = modifier.fillMaxSize()) {

        ExposedDropdownMenuBox(
            expanded = viewModel.expanded,
            onExpandedChange = { viewModel.toggleDropdown() },
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            OutlinedTextField(
                value = viewModel.sortItem,
                onValueChange = {},
                readOnly = true,
                label = {   Text(
                    "Semester Coursework",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Normal,
                        color = GradeMateColors.Primary
                    ))
                },
                trailingIcon = {
                    Icon(
                        Icons.Default.KeyboardArrowDown,
                        contentDescription = null,
                        tint = GradeMateColors.Primary
                    )
                },
                modifier = Modifier.menuAnchor().fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GradeMateColors.Primary,
                    unfocusedBorderColor = GradeMateColors.Primary,
                    focusedLabelColor = GradeMateColors.Primary,
                    unfocusedLabelColor = GradeMateColors.Primary,
                ),
                textStyle = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = GradeMateColors.Primary
                )
            )

            ExposedDropdownMenu(
                expanded = viewModel.expanded,
                onDismissRequest = { viewModel.closeDropdown() }
            ) {
                sorting.forEach { item ->
                    DropdownMenuItem(
                        text = { Text(item) },
                        onClick = {
                            val (level, sem) = parseSortItem(item)
                            viewModel.closeDropdown()
                            viewModel.loadForSelection(
                                level,
                                sem,
                                gradeList,
                                loadGrades
                            )
                        }
                    )
                }
            }
        }

        if (viewModel.loading || isLoading) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else if (viewModel.currentGrades.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 40.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "No coursework has been submitted for this semester.",
                    fontSize = 16.sp,
                    color = GradeMateColors.Primary
                )
            }
        } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {

                item {
                    val totalPassed =
                        viewModel.currentGrades.count { it.caMark >= 30 }
                    val totalFailed =
                        viewModel.currentGrades.count { it.caMark in 1.0..29.9 }
                    val total = viewModel.currentGrades.size
                    val totalPending = total - (totalPassed + totalFailed)

                    GradeSummary(
                        passed = totalPassed,
                        failed = totalFailed,
                        pending = totalPending,
                        total = total
                    )
                }

                items(viewModel.currentGrades) { grade ->
                    GradeCard(grade)
                }
            }
        }
    }
}


// --- Parse "Level 5 Semester 2" → Pair(5,2) ---
fun parseSortItem(item: String): Pair<Int, Int> {
    val parts = item.split(" ")
    val level = parts.getOrNull(1)?.toIntOrNull() ?: 4
    val sem = parts.getOrNull(3)?.toIntOrNull() ?: 1
    return Pair(level, sem)
}
