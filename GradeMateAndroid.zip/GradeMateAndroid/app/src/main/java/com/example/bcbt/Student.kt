package com.example.bcbt

import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.rememberCoroutineScope
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore
import kotlin.coroutines.coroutineContext

data class Student(
    var studentName: String = "",
    var regNo: String = "",
    var gender: String = "",
    var ntaLevel: String = "",
    var semester: String = "",
    var program: String = "",
    var collegeId: String = "",
    var photoPath: String = ""
)
val studentList = mutableStateListOf<Student>()

@RequiresApi(Build.VERSION_CODES.O)
fun loadStudent() {
    val db = Firebase.firestore
    val regNo = Auth.id.value

    if (regNo.isBlank()) {
        println("Auth ID is blank — cannot load student")
        return
    }

    db.collection("students")
        .whereEqualTo("regNo", regNo)
        .get()
        .addOnSuccessListener { result ->
            studentList.clear()
            for (document in result) {
                val student = document.toObject(Student::class.java)
                studentList.add(student)
                Constants.ntaLevel.intValue = studentList[0].ntaLevel.trim().toInt()
                Constants.mySemester.intValue = studentList[0].semester.trim().toInt()
                Constants.collegeId.value = studentList[0].collegeId.trim()
            }

            if (studentList.isNotEmpty()) {
                println("Student loaded: ${studentList.first().studentName}")
                loadCollegeInfo()

                loadModules()

                loadGrades(   Constants.ntaLevel.intValue , Constants.mySemester.intValue )
                loadPublish()
            } else {
                println("No student found for regNo: $regNo")
            }
        }
        .addOnFailureListener { e ->
            println("Error loading student: $e")
        }
}


