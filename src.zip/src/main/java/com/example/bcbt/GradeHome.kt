package com.example.bcbt

import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.google.firebase.Firebase
import com.google.firebase.auth.auth

// --- Auth state holder ---
@OptIn(ExperimentalMaterial3Api::class)
object Auth {
    private val _id = mutableStateOf("")
    val id: State<String> get() = _id
    fun setId(newId: String) { _id.value = newId }

    var noModules = mutableStateOf("")
    var totalCredits = mutableDoubleStateOf(0.0)
    var totalPassedPercent = mutableDoubleStateOf(0.0)
    var totalFailedPercent = mutableDoubleStateOf(0.0)
}

// --- Extension functions to derive NTA level and semester from moduleCode ---
fun Grade.getNtaLevel(): Int {
    return moduleCode.filter { it.isDigit() }.getOrNull(1)?.digitToInt() ?: 0
}

fun Grade.getSemester(): Int {
    return moduleCode.filter { it.isDigit() }.getOrNull(2)?.digitToInt() ?: 0
}

// --- GradeHome Composable ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GradeHome(navController: NavController) {
    BackHandler(enabled = true) {}

    StatusBar()

    var bottomIndex by remember { mutableIntStateOf(0) }
    var showDialog by remember { mutableStateOf(false) }
    var showLogoutDialog by remember { mutableStateOf(false) }

    // Logout dialogs
    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = { Text("Confirm Logout") },
            text = { Text("Are you sure you want to log out?") },
            confirmButton = {
                TextButton(onClick = {
                    Firebase.auth.signOut()
                    navController.navigate(Routes.gradeSplash)
                    showLogoutDialog = false
                    studentList.clear()
                    gradeList.clear()
                }) { Text("Logout") }
            },
            dismissButton = { TextButton(onClick = { showLogoutDialog = false }) { Text("Cancel") } }
        )
    }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = { showDialog = false },
            title = { Text("Confirm Logout") },
            text = { Text("Are you sure you want to log out?") },
            confirmButton = {
                TextButton(onClick = {
                    clearAuth()
                    Firebase.auth.signOut()
                    navController.navigate(Routes.gradeSplash) {
                        popUpTo(navController.graph.startDestinationId) { inclusive = true }
                    }
                    showDialog = false
                }) { Text("Logout") }
            },
            dismissButton = { TextButton(onClick = { showDialog = false }) { Text("Cancel") } }
        )
    }

    Scaffold(
        floatingActionButton = {
            if (bottomIndex == 0) {
                FloatingActionButton(
                    onClick = { navController.navigate(Routes.home) },
                    modifier = Modifier.padding(16.dp),
                    containerColor = GradeMateColors.Primary,
                    contentColor = Color.White,
                    elevation = FloatingActionButtonDefaults.elevation(8.dp)
                ) {
                    Icon(
                        painter = painterResource(R.drawable.website),
                        contentDescription = "Open BCBT website",
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        },
        topBar = {
            CenterAlignedTopAppBar(
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = GradeMateColors.Primary
                ),
                title = {
                    val titles = listOf(Constants.title, "Coursework", "Examination Results", "Settings")
                    Text(
                        text = titles.getOrElse(bottomIndex) { "" },
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.SemiBold
                    )
                },
                actions = {
                    IconButton(
                        onClick = { showLogoutDialog = true },
                        modifier = Modifier.size(48.dp)
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ExitToApp,
                            contentDescription = "Logout",
                            tint = GradeMateColors.Background,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }
            )
        },
        bottomBar = {
            NavSection(selectedIndex = bottomIndex) { index -> bottomIndex = index }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(GradeMateColors.backGradient),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (studentList.isNotEmpty()) {
                val screen: @Composable () -> Unit = {
                    when (bottomIndex) {
                        0 -> if (studentList.isNotEmpty()) Landing() else NotPublished("No students available yet")

                        1 -> { // Coursework
                            val publishItem = publish.firstOrNull()

                            if (publishItem != null && publishItem.coursework == "allowed") {
                                // Always show the Coursework composable, even if no grades exist
                                Coursework(
                                    studentList = studentList,
                                    gradeList = gradeList,
                                    isLoading = isLoading,
                                    loadStudent = { loadStudent() },
                                    loadGrades = { nta, sem -> loadGrades(nta, sem) }
                                )
                            } else {
                                // Coursework not published message
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .wrapContentSize()
                                            .clip(RoundedCornerShape(16.dp))
                                            .background(GradeMateColors.back1)
                                            .border(1.dp, GradeMateColors.Primary, RoundedCornerShape(16.dp))
                                            .padding(horizontal = 24.dp, vertical = 16.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        // Optional icon
                                        Icon(
                                            painter = painterResource(R.drawable.info), // or any info icon
                                            contentDescription = "Info",
                                            tint = GradeMateColors.Primary,
                                            modifier = Modifier.size(36.dp)
                                        )

                                        Spacer(modifier = Modifier.height(12.dp))

                                        Text(
                                            text = "The administrator has not released coursework results yet.",
                                            color = GradeMateColors.Primary,
                                            style = MaterialTheme.typography.titleMedium,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                        )
                                    }
                                }

                            }
                        }

                        2 -> { // Examination Results
                            val publishItem = publish.firstOrNull()
                            val resultsToShow = getLatestGrades(gradeList)

                            if (publishItem != null && publishItem.results == "allowed") {
                                if (resultsToShow.isNotEmpty()) {
                                    // ✅ Show results normally
                                    GradeResults(gradeList = resultsToShow)
                                } else {
                                    // ✅ Show GPA box + dropdown (without "No results available")
                                    ResultCard()
                                }
                            } else {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .wrapContentSize()
                                            .clip(RoundedCornerShape(16.dp))
                                            .background(GradeMateColors.back1)
                                            .border(1.dp, GradeMateColors.Primary, RoundedCornerShape(16.dp))
                                            .padding(horizontal = 24.dp, vertical = 16.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        // Optional icon
                                        Icon(
                                            painter = painterResource(R.drawable.info), // or any info icon
                                            contentDescription = "Info",
                                            tint = GradeMateColors.Primary,
                                            modifier = Modifier.size(36.dp)
                                        )

                                        Spacer(modifier = Modifier.height(12.dp))

                                        Text(
                                            text = "The administrator has not released semester results yet.",
                                            color = GradeMateColors.Primary,
                                            style = MaterialTheme.typography.titleMedium,
                                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                        )
                                    }
                                }
                            }
                        }


                        3 -> Settings()
                        else -> Text("Unknown Screen", color = Color.Black)
                    }
                }
                screen()
            } else {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
        }
    }
}

// --- Navigation bar ---
@Composable
fun NavSection(selectedIndex: Int, navAction: (Int) -> Unit) {
    NavigationBar(containerColor = GradeMateColors.back1, tonalElevation = 0.dp) {
        navItems.forEachIndexed { index, nav ->
            val isSelected = selectedIndex == index
            val animatedColor by animateColorAsState(
                targetValue = if (isSelected) Color.White else GradeMateColors.Primary,
                label = "AnimatedNavColor"
            )
            val animatedElevation by animateDpAsState(
                targetValue = if (isSelected) 8.dp else 0.dp,
                label = "AnimatedElevation"
            )
            val shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)

            Box(
                modifier = Modifier
                    .padding(horizontal = 4.dp)
                    .weight(1f)
                    .height(56.dp)
                    .shadow(animatedElevation, shape, clip = false)
                    .clip(shape)
                    .background(if (isSelected) GradeMateColors.Primary else Color.Transparent)
                    .clickable { navAction(index) },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        painter = painterResource(nav.icon),
                        contentDescription = nav.label,
                        tint = animatedColor,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        nav.label,
                        color = animatedColor,
                        fontWeight = FontWeight.SemiBold,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }
    }
}

// --- Get latest grades by NTA & Semester ---
fun getLatestGrades(grades: List<Grade>): List<Grade> {
    return grades.groupBy { "${it.getNtaLevel()}-${it.getSemester()}" }
        .maxByOrNull { (key, _) ->
            val (lvl, sem) = key.split("-").map { it.toInt() }
            lvl * 10 + sem
        }?.value ?: emptyList()
}

// --- Clear auth ---
fun clearAuth() {
    Auth.setId("")
    Auth.noModules.value = ""
    Auth.totalCredits.doubleValue = 0.0
    moduleList.clear()
    studentList.clear()
}
