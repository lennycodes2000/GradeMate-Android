package com.example.bcbt

import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine

class LandingViewModel : ViewModel() {

    var isLoaded by mutableStateOf(false)
        private set

    var student by mutableStateOf<Student?>(null)
        private set

    fun loadData() {
        // Prevent reloading unnecessarily
        if (isLoaded && student != null) return

        viewModelScope.launch {
            try {
                if (studentList.isEmpty()) {
                    loadStudent()
                }

                loadGrades(
                    Constants.ntaLevel.intValue,
                    Constants.mySemester.intValue
                )

                student = studentList.firstOrNull()
                isLoaded = student != null
            } catch (e: Exception) {
                Log.e("LandingVM", "Data loading failed", e)
                isLoaded = false
            }
        }
    }
}




