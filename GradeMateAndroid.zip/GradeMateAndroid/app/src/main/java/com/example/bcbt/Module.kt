package com.example.bcbt
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Call
import androidx.compose.material3.*
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.provider.Settings
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore
import kotlinx.coroutines.tasks.await

/*
 i want to show modules but also using the module.tutor
 from module to try get the tutor name and phone given the tutor email equals module.tutor
*/
data class Module(
    var name: String = "",
    var courses: List<String> = emptyList(),
    var credit: String = "",
    var level: String = "",
    var semester: String = "",
    var code: String = "",
    var tutor: String = "",
)
data class Tutor(
    var email:String = "",
    var phone:String = "",
    var tutorName: String = ""
)

val moduleList = mutableStateListOf<Module>()
val tutorList = mutableStateListOf<Tutor>()

//function to load Tutors
fun loadTutors() {
    val db = Firebase.firestore


    db.collection("tutors")
        .whereEqualTo("collegeId", Constants.collegeId.value)
        .get()
        .addOnSuccessListener { result ->
            tutorList.clear() // ✅ Clear before loop
            for (document in result) {
                val tutor = document.toObject(Tutor::class.java)
                tutorList.add(tutor)
            }
            Log.d("Tutors",tutorList.toList().toString())
        }
        .addOnFailureListener { exception ->
            println("Error loading modules: $exception")
        }
}
// the function to loadModules
@RequiresApi(Build.VERSION_CODES.O)
fun loadModules() {
    loadTutors()
val db = Firebase.firestore
    // ✅ Ensure student data is loaded before accessing studentList[0]
    if (studentList.isEmpty()) {
        println("Student list is empty. Cannot load modules.")
        return
    }

    db.collection("modules")
        .whereEqualTo("level", Constants.ntaLevel.intValue.toString())
        .whereEqualTo("semester", Constants.mySemester.intValue.toString())
        .whereEqualTo("collegeId", Constants.collegeId.value)
        .get()
        .addOnSuccessListener { result ->
            moduleList.clear() // ✅ Clear before loop
            for (document in result) {
                val module = document.toObject(Module::class.java)
                moduleList.add(module)
            }

            Auth.noModules.value = moduleList.size.toString()
            Auth.totalCredits.value = moduleList.sumOf { it.credit.toDouble() }
            Log.d("Azir",moduleList.toString())
        }
        .addOnFailureListener { exception ->
            println("Error loading modules: $exception")
        }
}






// Helper to update stats after adding modules
private fun updateModuleStats() {
    Auth.noModules.value = moduleList.size.toString()
    Auth.totalCredits.doubleValue = moduleList.sumOf { it.credit.toDoubleOrNull() ?: 0.0 }
}


@Composable
fun ModuleList(modules: List<Module>, studentProgram: String) {
    val filteredModules = modules.filter { it.courses.contains(studentProgram) }

    LazyColumn(
        modifier = Modifier
            .fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(filteredModules) { module ->
            ModuleCard(module)
        }
    }
}

@Composable
fun ModuleCard(module: Module) {
    val tutor = tutorList.find { it.email == module.tutor }
    val context = LocalContext.current
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 8.dp
        ),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
        ) {
            // Module Name + Tutor Avatar
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = module.name,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = GradeMateColors.Primary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Code: ${module.code}",
                        fontSize = 14.sp,
                        color = Color.DarkGray
                    )
                    Text(
                        text = "Credits: ${module.credit}",
                        fontSize = 14.sp,
                        color = Color.Gray
                    )
                }
                if (tutor?.tutorName?.isNotBlank() == true) {
                    // Optional: Tutor Avatar Circle
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(GradeMateColors.Primary.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        val titles = setOf(
                            "Mr","Mrs","Miss","Ms","Mx","Madam","Ma'am",
                            "Dr","Prof","PhD","MD","Eng","Sir","Lady",
                            "Rev","Fr","Sr","Sheikh","Imam","Rabbi",
                            "Capt","Col","Gen","Lt"
                        )

                        val initials = tutor?.tutorName
                            ?.split(" ")
                            ?.filter { it.replace(".", "") !in titles } // remove dots in titles like "Dr."
                            ?.take(2)
                            ?.map { it.firstOrNull()?.uppercaseChar() ?: ' ' }
                            ?.joinToString("")
                            ?: "T" // Default if name is null or empty

                        Text(
                            text = initials,
                            color = GradeMateColors.Primary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }


            }

            Spacer(modifier = Modifier.height(8.dp))

            tutor?.takeIf { it.tutorName.isNotBlank() }?.let { t ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Tutor: ${t.tutorName}",
                        fontSize = 14.sp,
                        color = Color.Gray,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )

                    t.phone.takeIf { it.isNotBlank() }?.let {
                        OutlinedButton(
                            onClick = {
                                // Trigger call intent
                                val intent = Intent(Intent.ACTION_DIAL).apply {
                                    data = Uri.parse("tel:${tutor.phone}") // lowercase 'parse'
                                }
                                context.startActivity(intent)
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                containerColor = GradeMateColors.Primary.copy(alpha = 0.1f),
                                contentColor = GradeMateColors.Primary
                            ),
                            border = BorderStroke(1.dp, GradeMateColors.Primary),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Icon(Icons.Default.Call, contentDescription = "Call Tutor", modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Call", fontSize = 14.sp)
                        }
                    }
                }
            }


        }
    }
}

