package com.example.bcbt

import android.util.Log
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.EaseInCubic
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun Landing() {
    val ElegantBorder = Color(0xFFCFD8DC)
    val CardBackground = Color.White

    // Track loading state
    var isLoaded by remember { mutableStateOf(studentList.isNotEmpty()) }

    // Load data if empty
    if (!isLoaded) {
        LaunchedEffect(Unit) {
            try {
                loadStudent()
                loadGrades(Constants.ntaLevel.intValue, Constants.mySemester.intValue)
            } catch (e: Exception) {
                Log.e("Landing", "Data loading failed: $e")
            }
            isLoaded = studentList.isNotEmpty()
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            GradeMateColors.Primary.copy(alpha = 0.15f),
                            Color.White
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = GradeMateColors.Primary)
        }
        return
    }

    // Safe access
    val student = remember(studentList) { studentList.first() }
    val charGender = remember(student) { if (student.gender == "Male") "M" else "F" }

    // Animated card entrance
    val transition = rememberInfiniteTransition()
    val cardOffsetY by transition.animateFloat(
        initialValue = -10f,
        targetValue = 10f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 6000,
                easing = LinearOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        )
    )


    Crossfade(targetState = isLoaded) { loaded ->
        if (loaded) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                GradeMateColors.Primary.copy(alpha = 0.15f),
                                Color.White
                            )
                        )
                    )
            ) {
                // Top section with gradient background
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(GradeMateColors.Primary)
                        .padding(top = 32.dp, start = 16.dp, end = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp)
                    ) {
                        // Profile Card
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.TopCenter)
                                .padding(top = 20.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(CardBackground)
                                .border(
                                    1.dp,
                                    ElegantBorder,
                                    RoundedCornerShape(16.dp)
                                )
                                .padding(top = 56.dp, bottom = 16.dp, start = 16.dp, end = 16.dp)
                                .offset(y = cardOffsetY.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "${student.studentName} ( $charGender )",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GradeMateColors.Primary,
                                    modifier = Modifier.padding(bottom = 4.dp)
                                )
                                Text(
                                    text = student.regNo,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Normal,
                                    color = Color.Gray
                                )
                            }
                        }

                        // Gradient Profile Image Ring
                        Box(
                            modifier = Modifier
                                .size(110.dp)
                                .align(Alignment.TopCenter)
                                .offset(y = (-48).dp)
                                .clip(CircleShape)
                                .background(
                                    brush = Brush.linearGradient(
                                        colors = listOf(
                                            GradeMateColors.Primary,
                                            GradeMateColors.back1
                                        )
                                    )
                                )
                                .padding(4.dp)
                        ) {
                            Image(
                                painter = painterResource(R.drawable.dp),
                                contentDescription = "Profile Image",
                                modifier = Modifier
                                    .clip(CircleShape)
                                    .shadow(8.dp, CircleShape),
                                contentScale = ContentScale.Crop
                            )
                        }
                    }
                }

                Spacer(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(32.dp)
                        .background(GradeMateColors.Primary)
                )

                // Bottom White Section
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
                        .background(Color.White)
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Top
                ) {
                    // Small Info Boxes
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SmallBox(title = "NTA Level", value = student.ntaLevel, modifier = Modifier.weight(1f))
                        SmallBox(title = "Semester", value = student.semester, modifier = Modifier.weight(1f))
                        SmallBox(title = "Program", value = student.program, modifier = Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Text(
                        "Semester Modules",
                        fontSize = 18.sp,
                        color = GradeMateColors.Primary,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Module List
                    ModuleList(modules = moduleList, studentProgram = student.program)
                }
            }
        } else {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = GradeMateColors.Primary)
            }
        }
    }
}

@Composable
fun SmallBox(title: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(1.dp, GradeMateColors.Primary, RoundedCornerShape(16.dp))
            .padding(8.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = title,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = GradeMateColors.Primary,
            modifier = Modifier.padding(bottom = 4.dp)
        )
        Text(
            text = value,
            fontSize = 16.sp,
            fontWeight = FontWeight.Normal,
            color = Color.Gray
        )
    }
}
