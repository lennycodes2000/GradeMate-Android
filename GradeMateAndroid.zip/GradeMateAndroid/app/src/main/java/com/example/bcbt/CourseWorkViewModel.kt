package com.example.bcbt

// Compose
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Coroutine
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// Logging
import android.util.Log
// Optional: for icons
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown

class CourseworkViewModel : ViewModel() {

    var sortItem by mutableStateOf("")
        private set

    var expanded by mutableStateOf(false)
        private set

    var currentGrades by mutableStateOf<List<Grade>>(emptyList())
        private set

    var loading by mutableStateOf(true)
        private set

    /** Helper: get grades for a level/semester */
    private fun getGradesFor(
        gradeList: List<Grade>,
        level: Int,
        sem: Int
    ) = gradeList.filter {
        it.getNtaLevel() == level && it.getSemester() == sem
    }

    /** Helper: previous semester */
    private fun previousSemester(level: Int, sem: Int): Pair<Int, Int>? = when {
        level == 4 && sem == 1 -> null
        sem == 1 -> Pair(level - 1, 2)
        else -> Pair(level, sem - 1)
    }

    /** Initial load with fallback */
    fun loadInitial(
        studentList: List<Student>,
        gradeList: List<Grade>,
        loadStudent: suspend () -> Unit,
        loadGrades: suspend (Int, Int) -> Unit
    ) {
        if (!loading && currentGrades.isNotEmpty()) return

        viewModelScope.launch {
            loading = true

            if (studentList.isEmpty()) {
                loadStudent()
            }

            val level =
                studentList.firstOrNull()?.ntaLevel?.toIntOrNull() ?: 4
            val sem =
                studentList.firstOrNull()?.semester?.toIntOrNull() ?: 1

            var l = level
            var s = sem

            loadGrades(l, s)
            delay(300)

            var grades = getGradesFor(gradeList, l, s)

            while (grades.isEmpty()) {
                val prev = previousSemester(l, s) ?: break
                l = prev.first
                s = prev.second

                loadGrades(l, s)
                delay(1500)
                grades = getGradesFor(gradeList, l, s)
            }

            currentGrades = grades
            sortItem = "Level $l Semester $s"
            loading = false
        }
    }

    /** Load for dropdown selection */
    fun loadForSelection(
        level: Int?,
        sem: Int?,
        gradeList: List<Grade>,
        loadGrades: suspend (Int, Int) -> Unit
    ) {
        if (level == null || sem == null) return

        viewModelScope.launch {
            loading = true
            try {
                loadGrades(level, sem)
                delay(1500)
                currentGrades = getGradesFor(gradeList, level, sem)
                sortItem = "Level $level Semester $sem"
            } catch (e: Exception) {
                Log.e("CourseworkVM", "Failed to load grades", e)
            } finally {
                loading = false
            }
        }
    }

    fun toggleDropdown() {
        expanded = !expanded
    }

    fun closeDropdown() {
        expanded = false
    }
}
