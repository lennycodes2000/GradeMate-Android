package com.example.bcbt

import android.util.Log
import androidx.compose.runtime.mutableStateListOf
import com.google.firebase.Firebase
import com.google.firebase.firestore.firestore

data class DownloadUpdate(
    var androidVersion: String = "",
    var linkAndroid:String = ""
)
val downloadUpdate = mutableStateListOf<DownloadUpdate>()
 fun loadDownloadUpdate() {
    Firebase.firestore.collection("downloadUpdate")
        .get()
        .addOnSuccessListener { querySnapshot ->
            if (!querySnapshot.isEmpty) {
                val document = querySnapshot.documents.first()

                val data = document.data
                if (data != null) {
                    val downloadSetting = DownloadUpdate(
                        androidVersion = data["androidVersion"] as? String ?: "",
                        linkAndroid = data["android"] as? String ?: ""
                    )

                    downloadUpdate.clear()
                    downloadUpdate.add(downloadSetting)

                    Log.d("Noreb", downloadUpdate.toString())
                }
            }
        }
        .addOnFailureListener {
            Log.e("Noreb", it.message ?: "Error loading download update")
        }
}
