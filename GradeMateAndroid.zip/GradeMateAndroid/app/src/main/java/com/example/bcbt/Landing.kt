package com.example.bcbt

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.firebase.auth.FirebaseAuth

@Composable
fun Landing(viewModel: LandingViewModel = viewModel()) {
    val ElegantBorder = Color(0xFFCFD8DC)
    val CardBackground = Color.White

    // Trigger loading ONCE, lifecycle-safe
    LaunchedEffect(Unit) {
        viewModel.loadData()
    }

    // Show loader while data is loading
    if (!viewModel.isLoaded) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            GradeMateColors.Primary.copy(alpha = 0.15f),
                            Color.White
                        )
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            CircularProgressIndicator(color = GradeMateColors.Primary)
        }
        return
    }

    // Safe access
    val student = viewModel.student ?: return
    val charGender = remember(student) {
        if (student.gender == "MALE") "M" else "F"
    }

    // Animated card entrance
    val transition = rememberInfiniteTransition()
    val cardOffsetY by transition.animateFloat(
        initialValue = -10f,
        targetValue = 10f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 6000,
                easing = LinearOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        )
    )

    Crossfade(targetState = viewModel.isLoaded) { loaded ->
        if (loaded) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                GradeMateColors.Primary.copy(alpha = 0.15f),
                                Color.White
                            )
                        )
                    )
            ) {
                // Top section
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(GradeMateColors.Primary)
                        .padding(top = 32.dp, start = 16.dp, end = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .align(Alignment.TopCenter)
                                .padding(top = 20.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(CardBackground)
                                .border(
                                    1.dp,
                                    ElegantBorder,
                                    RoundedCornerShape(16.dp)
                                )
                                .padding(
                                    top = 56.dp,
                                    bottom = 16.dp,
                                    start = 16.dp,
                                    end = 16.dp
                                )
                                .offset(y = cardOffsetY.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                collegeList.firstOrNull()?.collegeName
                                    ?.takeIf { it.isNotBlank() }
                                    ?.let { name ->
                                        Text(
                                            text = name,
                                            style = MaterialTheme.typography.titleMedium,
                                            textAlign = TextAlign.Center,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis,
                                            color = Color.Gray
                                        )
                                    }

                                Text(
                                    text = "${student.studentName} ( $charGender )",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GradeMateColors.Primary
                                )

                                Text(
                                    text = student.regNo,
                                    fontSize = 16.sp,
                                    color = Color.Gray
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .size(115.dp)
                                .align(Alignment.TopCenter)
                                .offset(y = (-48).dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        listOf(
                                            GradeMateColors.Primary,
                                            GradeMateColors.back1
                                        )
                                    )
                                )
                                .padding(4.dp)
                        ) {

                            val imageUrl =  student.photoPath  // get the url for image

                            ProfileImage(
                                photoUrl = imageUrl, // fallback to empty string if null
                                modifier = Modifier.size(120.dp)
                                    .clip(CircleShape)
                                    .shadow(8.dp, CircleShape)
                            )
                        }
                    }
                }

                Spacer(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(32.dp)
                        .background(GradeMateColors.Primary)
                )

                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
                        .background(Color.White)
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SmallBox("NTA Level", student.ntaLevel, Modifier.weight(1f))
                        SmallBox("Semester", student.semester, Modifier.weight(1f))
                        SmallBox("Program", student.program, Modifier.weight(1f))
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        "Semester Modules",
                        fontSize = 18.sp,
                        color = GradeMateColors.Primary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    ModuleList(
                        modules = moduleList,
                        studentProgram = student.program
                    )
                }
            }
        }
    }
}




@Composable
fun SmallBox(title: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .aspectRatio(1f)
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White)
            .border(1.dp, GradeMateColors.Primary, RoundedCornerShape(16.dp))
            .padding(8.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = title,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = GradeMateColors.Primary,
            modifier = Modifier.padding(bottom = 4.dp)
        )
        Text(
            text = value,
            fontSize = 16.sp,
            fontWeight = FontWeight.Normal,
            color = Color.Gray
        )
    }
}
