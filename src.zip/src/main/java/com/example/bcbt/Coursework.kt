package com.example.bcbt

import GradeCard
import GradeSummary
import android.R.attr.level
import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Coursework(
    modifier: Modifier = Modifier,
    studentList: List<Student>,
    gradeList: List<Grade>,
    isLoading: Boolean,
    loadStudent: suspend () -> Unit,
    loadGrades: suspend (Int, Int) -> Unit,
) {
    val coroutineScope = rememberCoroutineScope()

    // --- Determine current NTA level and semester from student ---
    val currentNtaLevel = studentList.firstOrNull()?.ntaLevel?.toIntOrNull() ?: 4
    val currentSemester = studentList.firstOrNull()?.semester?.toIntOrNull() ?: 1

    // --- Dropdown options ---
    val sorting = listOf(
        "Level 4 Semester 1",
        "Level 4 Semester 2",
        "Level 5 Semester 1",
        "Level 5 Semester 2",
        "Level 6 Semester 1",
        "Level 6 Semester 2"
    )

    var sortItem by remember { mutableStateOf("Level $currentNtaLevel Semester $currentSemester") }
    var expanded by remember { mutableStateOf(false) }
    var currentGrades by remember { mutableStateOf<List<Grade>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }

    // --- Helper: get grades for a level/semester ---
    fun getGradesFor(level: Int, sem: Int) =
        gradeList.filter { it.getNtaLevel() == level && it.getSemester() == sem }

    // --- Helper: find previous semester ---
    fun previousSemester(level: Int, sem: Int): Pair<Int, Int>? = when {
        level == 4 && sem == 1 -> null
        sem == 1 -> Pair(level - 1, 2)
        else -> Pair(level, sem - 1)
    }

    // --- Initial load with fallback ---
    suspend fun loadGradesInitial(level: Int, sem: Int) {
        loading = true
        loadGrades(level, sem)
        delay(300)
        var grades = getGradesFor(level, sem)
        var l = level
        var s = sem
        while (grades.isEmpty()) {
            val prev = previousSemester(l, s) ?: break
            l = prev.first
            s = prev.second
            loadGrades(l, s)
            delay(1500)
            grades = getGradesFor(l, s)
        }
        currentGrades = grades
        sortItem = "Level $l Semester $s"
        loading = false
    }

    // --- Load grades when level & semester are valid ---
    fun loadGradesForSelection(level: Int?, sem: Int?) {
        if (level == null || sem == null) return // skip if not ready

        coroutineScope.launch {
            loading = true
            try {
                loadGrades(level, sem) // fetch from Firestore
                // optional small delay for smoother UX
                delay(1500)
                currentGrades = getGradesFor(level, sem)
                sortItem = "Level $level Semester $sem"
            } catch (e: Exception) {
                Log.e("GradeFetch", "Failed to load grades: $e")
            } finally {
                loading = false
            }
        }
    }



    // --- Initial launch ---
    LaunchedEffect(Unit) {
        if (studentList.isEmpty()) loadStudent()
        val (level, sem) = parseSortItem(sortItem)
        loadGradesInitial(level, sem)
    }

    Column(modifier = modifier.fillMaxSize()) {
        // --- Dropdown always visible ---
        ExposedDropdownMenuBox(
            expanded = expanded,
            onExpandedChange = { expanded = !expanded },
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            OutlinedTextField(
                value = sortItem,
                onValueChange = {},
                readOnly = true,
                label = { Text("Semester Coursework") },
                trailingIcon = {
                    Icon(
                        imageVector = Icons.Default.KeyboardArrowDown,
                        contentDescription = "Dropdown",
                        tint = GradeMateColors.Primary
                    )
                },
                modifier = Modifier.menuAnchor().fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedContainerColor = Color.Transparent,
                    focusedContainerColor = Color.Transparent,
                    disabledContainerColor = Color.Transparent,
                    focusedBorderColor = GradeMateColors.Primary,
                    unfocusedBorderColor = GradeMateColors.Primary,
                    unfocusedLabelColor = GradeMateColors.Primary,
                    focusedLabelColor = GradeMateColors.Primary
                ),
                textStyle = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = GradeMateColors.Primary
                )
            )

            ExposedDropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                sorting.forEach { item ->
                    DropdownMenuItem(
                        text = { Text(item) }
                        ,onClick = {
                            val (level, sem) = parseSortItem(item)
                            expanded = false
                            loadGradesForSelection(level, sem)
                        }


                    )


                }
            }
        }

        // --- Content area ---
        if (loading || isLoading) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else if (currentGrades.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 40.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "No coursework has been submitted for this semester.",
                    fontSize = 16.sp,
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
                            color = GradeMateColors.Primary
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Top
            ) {
                // Grade summary
                item {
                    val totalPassed = currentGrades.count { it.caMark >= 30 }
                    val totalFailed = currentGrades.count { it.caMark in 1.0..29.9 }
                    val total = currentGrades.size
                    val totalPending = total - (totalPassed + totalFailed)

                    GradeSummary(
                        passed = totalPassed,
                        failed = totalFailed,
                        pending = totalPending,
                        total = total
                    )
                }

                // Grade cards
                items(currentGrades) { grade ->
                    GradeCard(grade)
                }
            }
        }
    }
}

// --- Parse "Level 5 Semester 2" → Pair(5,2) ---
fun parseSortItem(item: String): Pair<Int, Int> {
    val parts = item.split(" ")
    val level = parts.getOrNull(1)?.toIntOrNull() ?: 4
    val sem = parts.getOrNull(3)?.toIntOrNull() ?: 1
    return Pair(level, sem)
}
