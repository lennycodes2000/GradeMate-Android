package com.example.bcbt
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import coil.compose.AsyncImage

@Composable
fun ProfileImage(
    photoUrl: String,
    modifier: Modifier = Modifier // optional: make it circular
) {
    AsyncImage(
        model = photoUrl,
        contentDescription = "Profile Image",
        modifier = modifier,
        contentScale = ContentScale.Crop, // fills area, crops overflow
        placeholder = painterResource(id = R.drawable.dp),
        error = painterResource(id = R.drawable.dp)
    )
}


